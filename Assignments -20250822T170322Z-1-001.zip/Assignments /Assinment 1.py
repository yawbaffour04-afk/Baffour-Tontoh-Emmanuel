Python 3.13.5 (tags/v3.13.5:6cb20a2, Jun 11 2025, 16:15:46) [MSC v.1943 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.
>>> 'age=20'
'age=20'
>>> 'price=19.99'
'price=19.99'
>>> 'name="Baffour"'
'name="Baffour"'
>>> 'is_active=True'
'is_active=True'
>>> 
>>> B
Traceback (most recent call last):
  File "<pyshell#5>", line 1, in <module>
    B
NameError: name 'B' is not defined
>>> 'print(type(age))'
'print(type(age))'
>>> 'print(type(price))'
'print(type(price))'
>>> 'print(type(name)'
'print(type(name)'
>>> 'print(type(is_active))'
'print(type(is_active))'
>>> 
>>> 
>>> 'float_num=19.99'
'float_num=19.99'
>>> 'int_num=int(float_num)'
'int_num=int(float_num)'
>>> 'print(int_num,type(int_num)'
'print(int_num,type(int_num)'
>>> 
>>> 
>>> 'int_num=50'
'int_num=50'
>>> 'str_num=str(int_num)'
'str_num=str(int_num)'
>>> 'print(float_num,type(str_num))'
'print(float_num,type(str_num))'
>>> 
>>> 
'str_num="50"'
'str_num="50"'
'float_num=float(str_num)'
'float_num=float(str_num)'
'print(float_num,type(float_num))'
'print(float_num,type(float_num))'


first_name=input("Emmanuel:")
Emmanuel:
last_name=input("Baffour:")
Baffour:
print("Hello",+first_name+""+last_name+"!")
Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    print("Hello",+first_name+""+last_name+"!")
TypeError: bad operand type for unary +: 'str'
print("Hello,"+first_name+""+last_name+"!")
Hello,!


'age=20'
'age=20'
'print("You are"+str(age)+"years old.")
SyntaxError: unterminated string literal (detected at line 1)
'print("You are"+str(age)+"years old.")'
'print("You are"+str(age)+"years old.")'


Because you can not add a string to an integer directly.
SyntaxError: invalid syntax


word=input("fufu:")
fufu:
times=int(input("3:"))
3:
Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    times=int(input("3:"))
ValueError: invalid literal for int() with base 10: ''
print(word*times)
Traceback (most recent call last):
  File "<pyshell#43>", line 1, in <module>
    print(word*times)
NameError: name 'times' is not defined
print('word*times')
word*times


print("Hello")=SyntaxError
SyntaxError: cannot assign to function call here. Maybe you meant '==' instead of '='?
int("abc")=ValueError
SyntaxError: cannot assign to function call here. Maybe you meant '==' instead of '='?
"age"+10=TypeError
SyntaxError: cannot assign to expression here. Maybe you meant '==' instead of '='?
                     




 




 
