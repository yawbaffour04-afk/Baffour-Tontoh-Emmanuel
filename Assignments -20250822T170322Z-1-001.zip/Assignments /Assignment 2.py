def to_lowercase(s):
  return s.lower()
  print("Task 1:",to_lowercase("hello"))
  print("Task 1:",to_lowercase("here"))
  print("Task 1",to_lowercase("COME"))


def swap_case(s):
  return s.swap_case()
  print("Task 2:",swap_case("HeLLo WoRLd")) 


  remove_uppercase("Hello World")


  def count_upper_lower(s):
    upper_count = sum(1 for ch in s if ch .isupper())
    lower_count = sum(1 for ch in s if ch .islower())
    uc,lc = count_upper_lower("EngiNEEr")
    print("Task 4,uppercase(uc),lowercase(lc)")


    def remove_non_letter(s):
      return ".join(ch for ch in s if ch .isalpha())"
      print("Task 5:",remove_non_letters("Data-driven@2025!"))


      def heron_area(a,b,c):
        s = (a+b+c)/2
        return math.sqrt(s*(s-a)*(s-b)*(s-c))
        print("Task 6:",heron_area(3,4,5))


        def print_name_table(names):
          print("Name".ljust(15)),"length".rjust(7)
          print("-"*22)
          print("Task 7:")
          print_name_table("Alice","Bob","Yaw","Safo")



          def clean_string(s):
            s = s.strip()
            s = "".join(ch for ch in s if ch not in string.punctuation)
            s = s.replace("","")
            return s 
            print("Task 8:",clean_string("Hello,World!"))













