

Usage examples:
    > x = 5
    > y = 2*x + 1
    > def area(r) = pi * r^2
    > area(3)
    28.2743338823
    > :vars
    > :funcs
    > :save mycalc.json
    > :quit
"""

import ast
import math
import json
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Callable

# ----------------- Safe evaluator -----------------

ALLOWED_MATH = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
ALLOWED_BUILTINS = {
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
}
CONSTANTS = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
    "inf": math.inf,
    "nan": math.nan,
}

# Map caret ^ to power ** convenience
def normalize_expr(expr: str) -> str:
    # replace ^ with ** when used as operator (not in strings; we don't allow strings anyway)
    return expr.replace("^", "")

@dataclass
class UserFunc:
    args: List[str]
    expr_src: str  # original expression source
    expr_ast: ast.AST  # parsed AST

class SafeEval(ast.NodeVisitor):
    def _init_(self, variables: Dict[str, Any], functions: Dict[str, UserFunc]):
        self.variables = variables
        self.functions = functions

    def visit(self, node):
        return super().visit(node)

    def generic_visit(self, node):
        raise ValueError(f"Disallowed syntax: {type(node)._name_}")

    # Literals
    def visit_Constant(self, node: ast.Constant):
        if isinstance(node.value, (int, float, bool)) or node.value is None:
            return node.value
        raise ValueError("Only numeric and boolean constants are allowed.")

    # Names (variables / constants / functions are handled at Call)
    def visit_Name(self, node: ast.Name):
        if node.id in self.variables:
            return self.variables[node.id]
        if node.id in CONSTANTS:
            return CONSTANTS[node.id]
        # allow True/False
        if node.id in ("True", "False"):
            return True if node.id == "True" else False
        raise NameError(f"Unknown name: {node.id}")

    # Unary ops
    def visit_UnaryOp(self, node: ast.UnaryOp):
        operand = self.visit(node.operand)
        if isinstance(node.op, ast.UAdd):
            return +operand
        if isinstance(node.op, ast.USub):
            return -operand
        if isinstance(node.op, ast.Not):
            return not operand
        raise ValueError("Unsupported unary operator")

    # Binary ops
    def visit_BinOp(self, node: ast.BinOp):
        left = self.visit(node.left)
        right = self.visit(node.right)
        op = node.op
        if isinstance(op, ast.Add):
            return left + right
        if isinstance(op, ast.Sub):
            return left - right
        if isinstance(op, ast.Mult):
            return left * right
        if isinstance(op, ast.Div):
            return left / right
        if isinstance(op, ast.FloorDiv):
            return left // right
        if isinstance(op, ast.Mod):
            return left % right
        if isinstance(op, ast.Pow):
            return left ** right
        if isinstance(op, ast.MatMult):
            raise ValueError("Matrix multiply (@) not supported")
        raise ValueError("Unsupported binary operator")

    # Boolean ops
    def visit_BoolOp(self, node: ast.BoolOp):
        if isinstance(node.op, ast.And):
            val = True
            for v in node.values:
                val = val and bool(self.visit(v))
                if not val:
                    return False
            return True
        if isinstance(node.op, ast.Or):
            val = False
            for v in node.values:
                val = val or bool(self.visit(v))
                if val:
                    return True
            return False
        raise ValueError("Unsupported boolean operator")

    # Comparisons
    def visit_Compare(self, node: ast.Compare):
        left = self.visit(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            right = self.visit(comparator)
            if isinstance(op, ast.Eq):
                ok = left == right
            elif isinstance(op, ast.NotEq):
                ok = left != right
            elif isinstance(op, ast.Lt):
                ok = left < right
            elif isinstance(op, ast.LtE):
                ok = left <= right
            elif isinstance(op, ast.Gt):
                ok = left > right
            elif isinstance(op, ast.GtE):
                ok = left >= right
            else:
                raise ValueError("Unsupported comparison")
            if not ok:
                return False
            left = right
        return True

    # If expressions: a if cond else b
    def visit_IfExp(self, node: ast.IfExp):
        return self.visit(node.body) if self.visit(node.test) else self.visit(node.orelse)

    # Function calls
    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Name):
            name = node.func.id
            # Built-in math
            if name in ALLOWED_MATH:
                func = ALLOWED_MATH[name]
                args = [self.visit(a) for a in node.args]
                kwargs = {kw.arg: self.visit(kw.value) for kw in node.keywords}
                return func(*args, **kwargs)
            # Safe builtins
            if name in ALLOWED_BUILTINS:
                func = ALLOWED_BUILTINS[name]
                args = [self.visit(a) for a in node.args]
                return func(*args)
            # User-defined function
            if name in self.functions:
                uf = self.functions[name]
                if len(node.args) != len(uf.args):
                    raise TypeError(f"{name} expects {len(uf.args)} args, got {len(node.args)}")
                local_vars = dict(self.variables)  # shallow copy
                for arg_name, arg_val_node in zip(uf.args, node.args):
                    local_vars[arg_name] = self.visit(arg_val_node)
                return SafeEval(local_vars, self.functions).visit(uf.expr_ast)
        raise ValueError("Only simple function calls are allowed")

# ----------------- Calculator Core -----------------

class Calculator:
    def _init_(self):
        self.vars: Dict[str, Any] = {}
        self.funcs: Dict[str, UserFunc] = {}

    def eval_expr(self, expr: str) -> Any:
        expr = normalize_expr(expr)
        try:
            node = ast.parse(expr, mode="eval")
        except SyntaxError as e:
            raise SyntaxError(f"Syntax error: {e}") from None
        return SafeEval(self.vars, self.funcs).visit(node.body)

    def assign(self, name: str, expr: str) -> Any:
        value = self.eval_expr(expr)
        self.vars[name] = value
        return value

    def define_func(self, header: str, expr: str):
        # header form: f(a,b,c)
        name, arglist = self._parse_func_header(header)
        expr = normalize_expr(expr)
        try:
            node = ast.parse(expr, mode="eval")
        except SyntaxError as e:
            raise SyntaxError(f"Function body syntax error: {e}") from None
        self.funcs[name] = UserFunc(args=arglist, expr_src=expr, expr_ast=node.body)

    def _parse_func_header(self, header: str) -> Tuple[str, List[str]]:
        header = header.strip()
        if "(" not in header or not header.endswith(")"):
            raise SyntaxError("Function header must look like: name(a,b,c)")
        name, rest = header.split("(", 1)
        name = name.strip()
        args = [a.strip() for a in rest[:-1].split(",")] if rest[:-1].strip() else []
        if not name.isidentifier():
            raise SyntaxError("Invalid function name")
        for a in args:
            if not a.isidentifier():
                raise SyntaxError(f"Invalid argument name: {a}")
        return name, args

    def del_name(self, name: str):
        if name in self.vars:
            del self.vars[name]
        elif name in self.funcs:
            del self.funcs[name]
        else:
            raise NameError(f"No such variable or function: {name}")

    def save(self, path: str):
        data = {
            "vars": self.vars,
            "funcs": {
                k: {"args": v.args, "expr": v.expr_src}
                for k, v in self.funcs.items()
            }
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return path

    def load(self, path: str):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        self.vars = data.get("vars", {})
        self.funcs = {}
        for name, spec in data.get("funcs", {}).items():
            self.define_func(f"{name}({','.join(spec['args'])})", spec["expr"])

    def list_vars(self) -> List[Tuple[str, Any]]:
        return sorted(self.vars.items())

    def list_funcs(self) -> List[Tuple[str, str]]:
        return sorted((name, f"{name}({', '.join(uf.args)}) = {uf.expr_src}") for name, uf in self.funcs.items())

HELP_TEXT = """
Commands:
  :help                   Show this help
  :vars                   List defined variables
  :funcs                  List user-defined functions
  :del <name>             Delete a variable or function
  :save <file.json>       Save variables/functions to a JSON file
  :load <file.json>       Load variables/functions from a JSON file
  :quit / :exit           Quit the calculator

Expressions:
  - Use +, -, *, /, //, %, ^ (or **), comparisons (<, <=, >, >=, ==, !=), and boolean and/or/not.
  - Access math functions: sin(x), cos(x), tan(x), sqrt(x), log(x), exp(x), etc.
  - Constants: pi, e, tau, inf, nan
  - Assignment:   x = 2 * pi
  - Functions:    def f(a,b) = a^2 + b^2

Examples:
  x = 5
  y = 2*x + 1
  def hyp(a,b) = sqrt(a^2 + b^2)
  hyp(3,4)
"""

def repl():
    calc = Calculator()
    print("Programmable Calculator — type :help for help, :quit to exit.")
    while True:
        try:
            line = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line or line.startswith("#"):
            continue
        if line.startswith(":"):
            cmd = line[1:].strip().split()
            if not cmd:
                continue
            op = cmd[0].lower()
            args = cmd[1:]
            try:
                if op in ("quit", "exit"):
                    break
                elif op == "help":
                    print(HELP_TEXT.strip())
                elif op == "vars":
                    for k, v in calc.list_vars():
                        print(f"{k} = {v!r}")
                elif op == "funcs":
                    for _, s in calc.list_funcs():
                        print(s)
                elif op == "del":
                    if not args:
                        print("Usage: :del <name>")
                    else:
                        calc.del_name(args[0])
                elif op == "save":
                    if not args:
                        print("Usage: :save <file.json>")
                    else:
                        path = calc.save(args[0])
                        print(f"Saved to {path}")
                elif op == "load":
                    if not args:
                        print("Usage: :load <file.json>")
                    else:
                        calc.load(args[0])
                        print(f"Loaded from {args[0]}")
                else:
                    print("Unknown command. Type :help")
            except Exception as e:
                print(f"Error: {e}")
            continue

        # Function definition
        if line.lower().startswith("def "):
            try:
                # def f(a,b) = expr
                rest = line[4:].strip()
                if "=" not in rest:
                    raise SyntaxError("Use: def name(args) = expression")
                header, expr = rest.split("=", 1)
                calc.define_func(header.strip(), expr.strip())
                name = header.split("(", 1)[0].strip()
                print(f"Defined {name}")
            except Exception as e:
                print(f"Error: {e}")
            continue

        # Assignment or expression
        try:
            if "=" in line and not line.strip().startswith(("==", "!=")):
                name, expr = line.split("=", 1)
                name = name.strip()
                if not name.isidentifier():
                    raise SyntaxError("Left side of assignment must be a valid name")
                value = calc.assign(name, expr.strip())
                print(f"{name} = {value}")
            else:
                value = calc.eval_expr(line)
                print(value)
        except Exception as e:
            print(f"Error: {e}")

if _name_ == "_main_":
    repl()
''')

out_path = Path("/mnt/data/programmable_calculator.py")
out_path.write_text(code, encoding="utf-8")

print(f"Created: {out_path}")
print("\nQuick start:\n1) Download the file\n2) Run: python programmable_calculator.py\n")
print("Example session:\n> x = 5\n> def f(a,b) = a^2 + b^2\n> f(3,4)\n5**2 + f(3,4)")